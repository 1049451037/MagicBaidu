from .magic_baidu import MagicBaidu
