# MagicBaidu

Baidu search API. This is a brother repository of [MagicGoogle](https://github.com/howie6879/MagicGoogle).

# Requirement

* Python 3

# Installation

```shell
pip install MagicBaidu
```

# Tutorial

See [examples](https://github.com/1049451037/MagicBaidu/Examples/baidu_search.py)